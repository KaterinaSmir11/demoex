﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demoekz
{
    public static class CurrentUser
    {
        public static string userLogin { get; set; }
        public static int userID { get; set; }
    }
}
