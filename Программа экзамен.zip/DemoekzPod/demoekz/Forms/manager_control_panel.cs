﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demoekz
{
    public partial class manager_control_panel : Form
    {
        public manager_control_panel()
        {
            InitializeComponent();
        }

        private void button_manager_requests_Click(object sender, EventArgs e)
        {
            client_all_requests frm1 = new client_all_requests();
            this.Hide();
            frm1.ShowDialog();
            this.Close();
        }

        private void button_manager_messages_Click(object sender, EventArgs e)
        {

        }

        private void button_manager_reviews_Click(object sender, EventArgs e)
        {

        }
    }
}
