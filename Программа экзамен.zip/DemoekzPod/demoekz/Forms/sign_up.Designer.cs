﻿
namespace demoekz
{
    partial class sign_up
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_login = new System.Windows.Forms.TextBox();
            this.textBox_password = new System.Windows.Forms.TextBox();
            this.button_registration = new System.Windows.Forms.Button();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.linkLabel_toLogin = new System.Windows.Forms.LinkLabel();
            this.textBox_phone_number = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label1.Location = new System.Drawing.Point(50, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Регистрация";
            // 
            // textBox_login
            // 
            this.textBox_login.Location = new System.Drawing.Point(16, 53);
            this.textBox_login.Name = "textBox_login";
            this.textBox_login.Size = new System.Drawing.Size(186, 20);
            this.textBox_login.TabIndex = 3;
            this.textBox_login.Text = "Логин";
            // 
            // textBox_password
            // 
            this.textBox_password.Location = new System.Drawing.Point(16, 80);
            this.textBox_password.Name = "textBox_password";
            this.textBox_password.Size = new System.Drawing.Size(186, 20);
            this.textBox_password.TabIndex = 4;
            this.textBox_password.Text = "Пароль";
            // 
            // button_registration
            // 
            this.button_registration.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.button_registration.Location = new System.Drawing.Point(26, 161);
            this.button_registration.Margin = new System.Windows.Forms.Padding(3, 15, 3, 3);
            this.button_registration.Name = "button_registration";
            this.button_registration.Size = new System.Drawing.Size(165, 31);
            this.button_registration.TabIndex = 5;
            this.button_registration.Text = "Зарегистрироваться";
            this.button_registration.UseVisualStyleBackColor = true;
            this.button_registration.Click += new System.EventHandler(this.button_registration_Click);
            // 
            // textBox_name
            // 
            this.textBox_name.Location = new System.Drawing.Point(16, 107);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(186, 20);
            this.textBox_name.TabIndex = 7;
            this.textBox_name.Text = "Имя";
            // 
            // linkLabel_toLogin
            // 
            this.linkLabel_toLogin.AutoSize = true;
            this.linkLabel_toLogin.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.linkLabel_toLogin.Location = new System.Drawing.Point(51, 205);
            this.linkLabel_toLogin.Margin = new System.Windows.Forms.Padding(3, 10, 3, 0);
            this.linkLabel_toLogin.Name = "linkLabel_toLogin";
            this.linkLabel_toLogin.Size = new System.Drawing.Size(104, 13);
            this.linkLabel_toLogin.TabIndex = 8;
            this.linkLabel_toLogin.TabStop = true;
            this.linkLabel_toLogin.Text = "Уже есть аккаунт?";
            this.linkLabel_toLogin.Click += new System.EventHandler(this.linkLabel_toLogin_Click);
            // 
            // textBox_phone_number
            // 
            this.textBox_phone_number.Location = new System.Drawing.Point(16, 134);
            this.textBox_phone_number.Name = "textBox_phone_number";
            this.textBox_phone_number.Size = new System.Drawing.Size(186, 20);
            this.textBox_phone_number.TabIndex = 10;
            this.textBox_phone_number.Text = "Тел.";
            // 
            // sign_up
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(222, 233);
            this.Controls.Add(this.textBox_phone_number);
            this.Controls.Add(this.linkLabel_toLogin);
            this.Controls.Add(this.textBox_name);
            this.Controls.Add(this.button_registration);
            this.Controls.Add(this.textBox_password);
            this.Controls.Add(this.textBox_login);
            this.Controls.Add(this.label1);
            this.Name = "sign_up";
            this.Text = "Регистрация";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_login;
        private System.Windows.Forms.TextBox textBox_password;
        private System.Windows.Forms.Button button_registration;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.LinkLabel linkLabel_toLogin;
        private System.Windows.Forms.TextBox textBox_phone_number;
    }
}

